from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout, authenticate
from django.db import IntegrityError
from .models import Project, Experiencia, Habilidad, Educacion
from django.contrib.auth.decorators import login_required
from .forms import HabilidadForm

@login_required
def home(request):
    projects = Project.objects.all()
    experiencia = Experiencia.objects.all()
    educaciones = Educacion.objects.all()  # Obtener todas las instancias de Educación
    return render(request, "home.html", {
        "projects": projects,
        "experiencias": experiencia,
        "educaciones": educaciones  # Agregar educaciones al contexto
    })

def registrar(request):
    if request.method == 'GET':
        return render(request, "registrar.html", {
            'form': UserCreationForm
        })
    else: 
        if request.POST["password1"] == request.POST["password2"]:
            try:
                user = User.objects.create_user(request.POST["username"], password=request.POST["password1"])
                user.save()
                login(request, user)
                return redirect("home")
            except IntegrityError:
                return render(request, "registrar.html", {
                    'form': UserCreationForm,
                    "error": "El nombre de usuario ya ha sido tomado. Por favor, elige otro nombre."
                    })
        else:
            return render(request, "registrar.html", {
                'form': UserCreationForm,
                "error": "Las contraseñas no coinciden."
                })
        
def cerrarSeccion(request):
    logout(request)
    return redirect('home')


def iniciarSeccion(request):
    if request.method == 'GET':
        return render(request, "InicioDeSeccion.html", {
            'form': AuthenticationForm
        })
    else:
        user = authenticate(request, username=request.POST["username"], password=request.POST["password"])
        if user is None:
            return render(request, "InicioDeSeccion.html", {
                'form': AuthenticationForm,
                "error": "Nombre de usuario y/o contraseña incorrectos."
            })
        else:
            login(request, user)
            return redirect("home")
        
def test1(request):
    habilidades = Habilidad.objects.all()
    return render(request, 'test1.html', {'habilidades': habilidades})

def crear_habilidad(request):
    if request.method == 'POST':
        form = HabilidadForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('test1') 
    else:
        form = HabilidadForm()

    return render(request, 'crear_habilidad.html', {'form': form})

def educacion_view(request):
    educaciones = Educacion.objects.all()
    context = {
        'educaciones': educaciones
    }
    return render(request, 'home.html', context)

def educacion_table_view(request):
    educaciones = Educacion.objects.all()
    return render(request, 'educacion_table.html', {'educaciones': educaciones})


