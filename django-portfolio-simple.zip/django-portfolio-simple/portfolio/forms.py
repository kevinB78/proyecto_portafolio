from django import forms
from .models import Habilidad

class HabilidadForm(forms.ModelForm):
    class Meta:
        model = Habilidad
        fields = ['nombre', 'nivel', 'descripcion']
