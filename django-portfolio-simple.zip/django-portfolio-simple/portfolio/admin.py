from django.contrib import admin
from .models import Project, Experiencia, Habilidad, Educacion

admin.site.register(Project)
admin.site.register(Experiencia)
admin.site.register(Habilidad)
admin.site.register(Educacion)