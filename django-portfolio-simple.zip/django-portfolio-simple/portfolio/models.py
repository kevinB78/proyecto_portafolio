from django.db import models
from django.db.models.fields import CharField, DateField, URLField
from django.db.models.fields.files import ImageField
from datetime import date

from django.shortcuts import render

class Project(models.Model):
    title = CharField(max_length=100)
    description = CharField(max_length=250)
    image = ImageField(upload_to="portfolio/images")
    url = URLField(blank=True)
    date = DateField(default=date.today)

    def __str__(self) -> str:
        return self.title
    
class Experiencia(models.Model):
    institucion_del_curso = models.CharField(max_length=255)
    descripcion_curso = models.TextField()
    fecha_curso = models.DateField()
    numero_horas = models.PositiveIntegerField()

    def __str__(self):
        return f"{self.institucion_del_curso} - {self.descripcion_curso}"

def test1(request):
    habilidades = Habilidad.objects.all()
    return render(request, 'test1.html', {'habilidades': habilidades})

class Habilidad(models.Model):
    LENGUAJES_OPCIONES = [
        ('Python', 'Python'),
        ('JavaScript', 'JavaScript'),
        ('Java', 'Java'),
        ('C++', 'C++'),
        ('Ruby', 'Ruby'),
        ('PHP', 'PHP'),
        ('Go', 'Go'),
        ('Swift', 'Swift'),
    ]

    NIVEL_OPCIONES = [
        ('Principiante', 'Principiante'),
        ('Intermedio', 'Intermedio'),
        ('Avanzado', 'Avanzado'),
    ]

    nombre = models.CharField(
        max_length=100, 
        choices=LENGUAJES_OPCIONES, 
        verbose_name="Nombre de la habilidad"
    )
    nivel = models.CharField(
        max_length=20, 
        choices=NIVEL_OPCIONES, 
        verbose_name="Nivel"
    )
    descripcion = models.TextField(
        blank=True, 
        null=True, 
        verbose_name="Descripción"
    )

    def __str__(self):
        return f"{self.id} {self.nombre} ({self.nivel})"


class Educacion(models.Model):
    institucion = models.CharField(max_length=255)
    descripcion = models.TextField()
    anio_inicio = models.IntegerField()
    anio_fin = models.IntegerField()

    def __str__(self):
        return self.institucion
