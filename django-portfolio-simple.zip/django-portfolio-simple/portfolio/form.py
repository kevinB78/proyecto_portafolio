from django import forms
from .models import Educacion

class EducacionForm(forms.ModelForm):
    class Meta:
        model = Educacion
        fields = ['institucion', 'descripcion', 'anio_inicio', 'anio_fin']
        widgets = {
            'institucion': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Nombre de la Institución'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'placeholder': 'Descripción'}),
            'anio_inicio': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Año de Inicio'}),
            'anio_fin': forms.NumberInput(attrs={'class': 'form-control', 'placeholder': 'Año de Finalización'}),
        }